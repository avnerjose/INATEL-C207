/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaobd.model;

/**
 *
 * @author PICHAU
 */
public class Filme {
    public int id;
    public String nome;
    public String diretor;
    public String genero;
    public float preco;
}
