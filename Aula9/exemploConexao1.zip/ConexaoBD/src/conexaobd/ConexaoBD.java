/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaobd;

import conexaobd.DAO.FilmeDAO;
import conexaobd.DAO.PessoaDAO;
import conexaobd.model.Filme;
import conexaobd.model.Pessoa;
import java.util.ArrayList;

/**
 *
 * @author PICHAU
 */
public class ConexaoBD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Filme f1 = new Filme();
        f1.nome = "Liga da Justiça";
        f1.diretor = "Snyder";
        f1.genero = "Ficção Científica";
        f1.preco = 5;
        
        FilmeDAO fDAO = new FilmeDAO();
        /*if(fDAO.inserirFilme(f1)){
            System.out.println("Consegui inserir");
        }else{
            System.out.println("Continua sofrendo aí...");
        }*/
        
        f1.genero = "Filme de Herói";
        f1.preco = 15;
        
        /*if(fDAO.atualizarFilme(1, f1)){
            System.out.println("Consegui atualizar");
        }
        else{
            System.out.println("Continue tentando...");
        }*/
        
        if(fDAO.deletarFilme(1)){
            System.out.println("Deletado");
        }
        else{
            System.out.println("Filme não quer ser jogado fora");
        }
        
    }
    
}
