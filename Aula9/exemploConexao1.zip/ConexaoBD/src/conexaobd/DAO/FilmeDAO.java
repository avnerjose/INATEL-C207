/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaobd.DAO;

import conexaobd.model.Filme;
import conexaobd.model.Pessoa;
import java.sql.SQLException;

/**
 *
 * @author PICHAU
 */
public class FilmeDAO extends ConnectionDAO{
    boolean sucesso = false;
    
    public boolean inserirFilme(Filme filme) {
        connectToDB();
        String sql = "INSERT INTO Filme (nome, diretor, genero, preco) values(?,?,?,?)";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, filme.nome);
            pst.setString(2, filme.diretor);
            pst.setString(3, filme.genero);
            pst.setFloat(4, filme.preco);
            pst.execute();
            sucesso = true;
        } catch(SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch(SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        
        return sucesso;
    }
    
        public boolean atualizarFilme(int id, Filme filme) {
        connectToDB();
        String sql = "UPDATE Filme SET genero=?, preco=? where id=?";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, filme.genero);
            pst.setFloat(2, filme.preco);
            pst.setInt(3, id);
            pst.execute();
            sucesso = true;
            
        } catch(SQLException ex) {
            System.out.println("Erro = " +  ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch(SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }
    
    public boolean deletarFilme(int id) {
        connectToDB();
        String sql = "DELETE FROM Filme where id=?";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            pst.execute();
            sucesso = true;
            
        } catch(SQLException ex) {
            System.out.println("Erro = " +  ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch(SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }
}
